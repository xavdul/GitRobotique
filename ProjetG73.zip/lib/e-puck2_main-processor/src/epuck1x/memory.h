#ifndef _MEMORY_
#define _MEMORY_

// MEMORY 
#define DEFAULT_WIDTH 52 // => 8.125% of max width
#define DEFAULT_HEIGHT 39 // => 8.125% of max height
#define BUFFER_SIZE (DEFAULT_WIDTH*DEFAULT_HEIGHT*2)+3+80

#endif /* _MEMORY_ */
