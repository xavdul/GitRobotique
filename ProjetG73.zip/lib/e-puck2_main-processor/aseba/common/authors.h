
#ifndef __ASEBA_AUTHORS_H
#define __ASEBA_AUTHORS_H

#define ASEBA_AUTHORS_FULL_LIST "Stéphane Magnenat \noriginal idea, architecture, core coder\n\nFlorian Vaussard \ncore coder, Windows maintainer (until 2015)\n\nPhilippe Retornaz \ncoder, embedded integration\n\nJiwon Shin \ncoder, VPL\n\nDavid James Sherman \nasebahttp, Scratch integration\n\nFabian Hahn \nBlockly integration\n\nMaria María Beltrán \nVPL design - funded by Gebert Rüf Stiftung\n\nManon Briod \nVPL design - funded by Gebert Rüf Stiftung\n\nSandra Moser \nGerman translation\n\nFrancisco Javier Botero Herrera \nSpanish translation\n\nEzio Somá \nItalian translation\n\nMichael Bonani \nFrench translation, packaging, testing\n\nFanny Riedo \nOS X maintainer\n\nValentin Longchamp \ninputs on framework architecture, additional coding\n\nBasilio Noris \ninputs on challenge, graphics design on challenge\n\n\n"

#endif // __ASEBA_AUTHORS_H
