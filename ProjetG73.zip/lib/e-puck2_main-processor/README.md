# e-puck2_main-processor
e-puck2 STM32F407 firmware
